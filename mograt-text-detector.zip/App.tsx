
import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route, NavLink } from 'react-router-dom';
import HomePage from './pages/HomePage';
import DetectorPage from './pages/DetectorPage';
import AboutPage from './pages/AboutPage';

// Define components outside parent to avoid re-renders
const SunIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
  </svg>
);

const MoonIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
  </svg>
);

const Header: React.FC<{ theme: string; toggleTheme: () => void }> = ({ theme, toggleTheme }) => (
    <header className="bg-white/80 dark:bg-gray-950/80 backdrop-blur-sm sticky top-0 z-50 shadow-md">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <NavLink to="/" className="text-2xl font-black text-royal-blue-800 dark:text-royal-blue-300">
              MOGRAT TEXT DETECTOR
            </NavLink>
          </div>
          <div className="flex items-center space-i-4">
             <NavLink to="/detector" className={({ isActive }) => `px-3 py-2 rounded-md text-sm font-medium ${isActive ? 'bg-royal-blue-100 dark:bg-royal-blue-900 text-royal-blue-800 dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'}`}>
              الكاشف
            </NavLink>
            <NavLink to="/about" className={({ isActive }) => `px-3 py-2 rounded-md text-sm font-medium ${isActive ? 'bg-royal-blue-100 dark:bg-royal-blue-900 text-royal-blue-800 dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'}`}>
              حول
            </NavLink>
            <button onClick={toggleTheme} className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none">
              {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
            </button>
          </div>
        </div>
      </nav>
    </header>
);

const Footer = () => (
  <footer className="w-full py-4 bg-white dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800 mt-auto">
    <div className="container mx-auto text-center text-gray-500 dark:text-gray-400 text-sm">
      All rights reserved © MOGRAT DEVELOPMENT | ALI ADIL
    </div>
  </footer>
);


export default function App() {
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light');
  
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  const userCountState = useState(() => parseInt(localStorage.getItem('userCount') || '0', 10));

  return (
    <HashRouter>
        <div className="bg-slate-50 dark:bg-gray-900 text-slate-800 dark:text-slate-200 min-h-screen flex flex-col transition-colors duration-300">
          <Header theme={theme} toggleTheme={toggleTheme} />
          <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8">
            <Routes>
              <Route path="/" element={<HomePage userCountState={userCountState} />} />
              <Route path="/detector" element={<DetectorPage />} />
              <Route path="/about" element={<AboutPage />} />
            </Routes>
          </main>
          <Footer />
        </div>
    </HashRouter>
  );
}
